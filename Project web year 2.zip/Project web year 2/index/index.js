function goTo(role) {
  if (role === "voter") {
    window.location.href = "/voter/login.html";
  } 
  else if (role === "candidate") {
    window.location.href = "/candidate/login.html";
  } 
  else if (role === "admin") {
    window.location.href = "/admin/login.html";
  }
}